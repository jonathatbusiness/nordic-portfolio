import { SectionPlaceholder } from "@/components/ui/SectionPlaceholder";

export function CountryOverview() {
  return (
    <SectionPlaceholder
      id="norway"
      eyebrow="Country Overview"
      title="Discover Norway"
      description="Explore Norway’s location, territorial area, climate, flag and connection with Brazil."
    />
  );
}
