import { ArrowDown, Images } from "lucide-react";
import { Container } from "@/components/ui/Container";

export function Hero() {
  return (
    <section
      id="home"
      className="relative flex min-h-screen scroll-mt-20 items-center overflow-hidden bg-slate-950 pt-20 text-white"
    >
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,rgba(185,28,28,0.35),transparent_36%),radial-gradient(circle_at_bottom_left,rgba(30,64,175,0.35),transparent_40%)]" />

      <div className="absolute inset-0 opacity-20 [background-image:linear-gradient(rgba(255,255,255,0.08)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.08)_1px,transparent_1px)] [background-size:42px_42px]" />

      <Container className="relative py-24 sm:py-32">
        <div className="max-w-4xl">
          <p className="mb-5 text-sm font-semibold uppercase tracking-[0.3em] text-red-400">
            Land of Vikings
          </p>

          <h1 className="text-balance text-6xl font-black uppercase tracking-tight sm:text-7xl lg:text-9xl">
            Norway
          </h1>

          <p className="mt-6 max-w-2xl text-pretty text-lg leading-8 text-slate-300 sm:text-xl">
            A land of breathtaking nature, rich history and strong traditions.
          </p>

          <p className="mt-5 text-sm text-slate-400">
            A school portfolio by Mateus Augusto Caetani
          </p>

          <div className="mt-9 flex flex-col gap-4 sm:flex-row">
            <a
              href="#norway"
              className="inline-flex min-h-12 items-center justify-center gap-2 rounded-full bg-red-700 px-6 font-semibold transition hover:bg-red-600"
            >
              Explore the Portfolio
              <ArrowDown size={18} />
            </a>

            <a
              href="#gallery"
              className="inline-flex min-h-12 items-center justify-center gap-2 rounded-full border border-white/20 bg-white/5 px-6 font-semibold transition hover:bg-white/10"
            >
              <Images size={18} />
              View Gallery
            </a>
          </div>
        </div>
      </Container>
    </section>
  );
}
